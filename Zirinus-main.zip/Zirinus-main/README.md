

# Zirinus
Discord spam tool that made with Python

# How to use
**Module installation is automatic**
## Spammer

Write your tokens to tokens.txt file.
If you want to spam with multiple tokens then go to new line

Write your channel ID to channel_ids.txt file.
If you want to spam multiple channels just go to new line

## Webhook Spammer
Write your webhook url to webhook config/webhook-url.txt

To use more than one webhook, just go to new line

# Features
- Ultimate webhook customization
- Ability to view message content from terminal
- Ability to send message from termimal
- Ability to use more than one token
- Ability to spam more than one channel
- Ability to spam webhooks
- Ability to spam more than one webhooks
- Ability to customize webhook avatar
- Ability to customize webhook username
- Ability to customize webhook footer
- Ability to customize webhook embed
- Automatic update system
- Ratelimit protection
- Cross platform OS functions

# Coming Features
- Token Bruteforce





# MY DISCORD: Shellˮ#2687
# Support Server
## https://discord.gg/8scYSxxmkF
